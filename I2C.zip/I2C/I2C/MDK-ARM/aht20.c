#include "aht20.h"

/**
 * @brief  初始化AHT20（发送校准命令）
 * @param  hi2c: I2C句柄（如&hi2c1）
 * @retval 0：成功；1：失败
 */
uint8_t AHT20_Init(I2C_HandleTypeDef *hi2c) {
  uint8_t init_data[3] = {AHT20_CMD_INIT, 0x08, 0x00};  // 初始化命令+参数（0x08使能校准）
  HAL_Delay(40);  // 上电后等待40ms稳定

  // 发送初始化命令
  if (HAL_I2C_Master_Transmit(hi2c, AHT20_ADDR, init_data, 3, 100) != HAL_OK) {
    return 1;  // 发送失败
  }
  HAL_Delay(10);  // 等待初始化完成
  return 0;
}

/**
 * @brief  读取AHT20温湿度数据
 * @param  hi2c: I2C句柄
 * @param  temp: 温度结果（输出，单位：℃）
 * @param  humi: 湿度结果（输出，单位：%RH）
 * @retval 0：成功；1：失败（超时或通信错误）
 */
uint8_t AHT20_ReadData(I2C_HandleTypeDef *hi2c, float *temp, float *humi) {
  uint8_t measure_cmd[3] = {AHT20_CMD_MEASURE, 0x33, 0x00};  // 测量命令+参数
  uint8_t data[6];  // 存储读取的6字节数据

  // 1. 发送测量命令
  if (HAL_I2C_Master_Transmit(hi2c, AHT20_ADDR, measure_cmd, 3, 100) != HAL_OK) {
    return 1;
  }

  // 2. 等待测量完成（最多等待200ms，状态位Bit7为0表示完成）
  uint32_t timeout = 200;
  while (timeout--) {
    HAL_Delay(1);
    // 读取状态字节（仅读1字节）
    if (HAL_I2C_Master_Receive(hi2c, AHT20_ADDR, data, 1, 100) == HAL_OK) {
      if ((data[0] & 0x80) == 0) {  // Bit7=0：测量完成
        break;
      }
    }
  }
  if (timeout == 0) {
    return 1;  // 超时
  }

  // 3. 读取6字节数据（状态+湿度+温度）
  if (HAL_I2C_Master_Receive(hi2c, AHT20_ADDR, data, 6, 100) != HAL_OK) {
    return 1;
  }

  // 4. 解析数据（AHT20数据格式：湿度20位，温度20位）
  // 湿度：data[1]（8位） + data[2]（8位） + data[3]高4位 → 共20位
  uint32_t humi_raw = ((uint32_t)data[1] << 12) | ((uint32_t)data[2] << 4) | (data[3] >> 4);
  // 温度：data[3]低4位 + data[4]（8位） + data[5]（8位） → 共20位
  uint32_t temp_raw = ((uint32_t)(data[3] & 0x0F) << 16) | ((uint32_t)data[4] << 8) | data[5];

  // 转换为实际值（公式来自AHT20手册）
  *humi = (humi_raw / (float)(1 << 20)) * 100;  // 湿度范围：0~100%RH
  *temp = (temp_raw / (float)(1 << 20)) * 200 - 50;  // 温度范围：-50~150℃

  return 0;
}
