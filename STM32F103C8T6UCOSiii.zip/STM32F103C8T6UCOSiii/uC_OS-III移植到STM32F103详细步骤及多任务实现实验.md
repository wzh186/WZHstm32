﻿# uC/OS-III移植到STM32F103详细步骤及多任务实现实验


## 一、实验目的
1. 深入掌握uC/OS-III在STM32F103上的移植细节，理解RTOS与硬件的接口原理。
2. 实现3个独立周期任务：1秒LED闪烁、3秒LED闪烁、2秒串口发送，验证多任务调度功能。
3. 掌握移植过程中关键文件的修改与配置方法。


## 二、实验环境
### 1. 硬件环境
- 主控制器：STM32F103C8T6（Cortex-M3内核，72MHz主频）
- 外设：LED（PA0、PA1）、USB转TTL模块（CH340）、ST-Link V2、杜邦线、5V电源
- 引脚连接：
  - LED1 → PA0（串联220Ω电阻到GND）
  - LED2 → PA1（串联220Ω电阻到GND）
  - 串口：STM32 PA9（USART1_TX）→ USB-TTL RX；STM32 PA10（USART1_RX）→ USB-TTL TX

### 2. 软件环境
- 开发工具：Keil MDK 5.36（需安装STM32F1xx器件包）
- 固件库：STM32CubeMX 6.6.0生成的HAL库（V1.8.4）
- uC/OS-III源码：V3.04.01（从Micrium官网下载，目录结构如下）：
  ```
  uCOS-III/
  ├─ uC-CPU/         // CPU架构相关代码
  ├─ uC-LIB/         // 通用库函数
  ├─ uC-OS-III/      // 内核核心代码
  └─ Ports/          // 处理器移植模板（含Cortex-M3）
  ```
- 辅助工具：STM32CubeMX、XCOM V2.0串口助手


## 三、移植详细步骤

### 阶段1：基础工程创建（STM32CubeMX）
#### 1.1 生成STM32基础工程
1. 打开STM32CubeMX，点击“New Project”，在芯片列表中搜索“STM32F103C8T6”并选中。
2. 配置系统时钟：
   - 进入“System Core → RCC”，勾选“HSE Clock”为“Crystal/Ceramic Resonator”（外部晶振）。
   - 进入“Clock Configuration”，设置PLL倍频：HSE=8MHz → PLLMUL=9 → SYSCLK=72MHz，APB1=36MHz，APB2=72MHz，点击“OK”。
3. 配置GPIO（LED）：
   - 进入“Pinout & Configuration → GPIO → PA0”，设置为“GPIO_Output”，命名为“LED1”。
   - 同样配置PA1为“GPIO_Output”，命名为“LED2”。
   - 在“GPIO Configuration”中，设置PA0、PA1的“GPIO mode”为“Output Push-Pull”，“GPIO Pull-up/Pull-down”为“Pull-up”（默认高电平，LED灭）。
4. 配置USART1（串口）：
   - 进入“Connectivity → USART1”，设置“Mode”为“Asynchronous”（异步模式）。
   - 配置参数：Baud Rate=115200，Word Length=8 Bits，Parity=None，Stop Bits=1。
   - 自动分配引脚：PA9（TX）、PA10（RX）（若未自动分配，手动设置）。
5. 生成工程：
   - 点击“Project Manager → Project”，设置工程名（如“uCOS_LED_UART”），选择路径（无中文），工具链选“MDK-ARM”。
   - 点击“Code Generator”，勾选：
     - “Generate peripheral initialization as a pair of .c/.h files per peripheral”
     - “Set all free pins as analog (to optimize power consumption)”
   - 点击“Generate Code”，生成后用Keil打开工程。

#### 1.2 验证基础工程
1. 在`main.c`的`while(1)`中添加LED闪烁测试代码：
   ```c
   HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);
   HAL_Delay(500);
   HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin);
   HAL_Delay(500);
   ```
2. 添加串口发送测试：
   ```c
   uint8_t tx_buf[] = "Test UART\n";
   HAL_UART_Transmit(&huart1, tx_buf, sizeof(tx_buf)-1, 100);
   ```
3. 编译下载，确认LED交替闪烁、串口能收到数据，硬件无误。


### 阶段2：uC/OS-III源码导入与工程配置
#### 2.1 准备uC/OS-III源码文件
1. 解压uC/OS-III源码，复制核心目录到工程目录下，新建`uCOS`文件夹，结构如下：
   ```
   uCOS/
   ├─ uC-CPU/         // 复制源码的uC-CPU目录
   │  ├─ ARM-Cortex-M3/  // 处理器相关（Cortex-M3）
   │  └─ cpu.c, cpu.h, ...
   ├─ uC-LIB/         // 复制源码的uC-LIB目录
   │  ├─ Lib/
   │  └─ lib_ascii.c, ...
   ├─ uC-OS-III/      // 复制源码的uC-OS-III目录
   │  ├─ Source/      // 内核源码
   │  └─ cfg/         // 配置文件模板
   └─ BSP/            // 自定义板级支持包
   ```

#### 2.2 在Keil中添加文件分组
1. 打开Keil工程，右键“Target 1”→“Manage Project Items”，添加以下分组：
   - `uC-CPU`：存放CPU相关文件
   - `uC-LIB`：存放库函数文件
   - `uC-OS-III`：存放内核文件
   - `uC-BSP`：存放板级支持文件

2. 向分组添加文件：
   - **`uC-CPU`**：
     - `uCOS/uC-CPU/cpu.c`
     - `uCOS/uC-CPU/ARM-Cortex-M3/cpu_core.c`（Cortex-M3核心代码）
     - `uCOS/uC-CPU/ARM-Cortex-M3/os_cpu_c.c`（移植C文件，需修改）
     - `uCOS/uC-CPU/ARM-Cortex-M3/os_cpu_a.asm`（移植汇编文件，需修改）
   - **`uC-LIB`**：
     - `uCOS/uC-LIB/lib_ascii.c`、`lib_math.c`、`lib_mem.c`、`lib_str.c`
   - **`uC-OS-III`**：
     - 内核核心文件：`uCOS/uC-OS-III/Source/os_core.c`、`os_task.c`、`os_time.c`、`os_int.c`、`os_mutex.c`（基础功能必选）
     - 配置文件：从`uC-OS-III/cfg`复制`os_cfg.h`、`app_cfg.h`到`uCOS/uC-OS-III`目录并添加
   - **`uC-BSP`**：新建`bsp.c`和`bsp.h`（板级初始化），添加到分组

![在这里插入图片描述](https://i-blog.csdnimg.cn/direct/d9330fc93182491783cabee17fcfe32c.png#pic_center)

### 阶段3：核心移植文件修改（关键步骤）
#### 3.1 配置`os_cfg.h`（内核参数）
打开`uCOS/uC-OS-III/os_cfg.h`，修改以下关键宏（其他保持默认）：
```c
// 系统时基配置（1ms中断一次）
#define OS_CFG_TICK_RATE_HZ             1000u   // 时基频率=1000Hz → 周期1ms
#define OS_CFG_ISR_STK_SIZE             128u    // 中断栈大小（字节）
#define OS_CFG_TASK_STK_LIMIT_EN        1u      // 启用栈溢出检查（调试用）
#define OS_CFG_MAX_TASKS                10u     // 最大任务数（至少3个）
#define OS_CFG_SCHED_LOCK_EN            1u      // 启用调度锁
#define OS_CFG_TIME_DLY_HMSM_EN         1u      // 启用OSTimeDlyHMSM()函数
```

#### 3.2 配置`app_cfg.h`（应用参数）
打开`uCOS/uC-OS-III/app_cfg.h`，添加任务优先级定义：
```c
// 任务优先级（数值越小，优先级越高）
#define APP_CFG_LED1_TASK_PRIO          5u
#define APP_CFG_LED2_TASK_PRIO          6u
#define APP_CFG_UART_TASK_PRIO          7u

// 任务栈大小（字节）
#define APP_CFG_LED1_TASK_STK_SIZE     128u
#define APP_CFG_LED2_TASK_STK_SIZE     128u
#define APP_CFG_UART_TASK_STK_SIZE     128u
```

#### 3.3 修改`os_cpu_c.c`（Cortex-M3移植C文件）
该文件实现任务栈初始化、中断处理等硬件相关接口，关键函数如下：

1. **任务栈初始化（`OSTaskStkInit`）**：
   Cortex-M3使用满递减栈（SP指向最后一个入栈元素），需按内核要求初始化栈帧（异常进入时自动入栈的寄存器）：
   ```c
   OS_STK *OSTaskStkInit (void (*task)(void *p_arg),
                         void       *p_arg,
                         OS_STK     *p_stk_base,
                         OS_STK     *p_stk_limit,
                         CPU_STK_SIZE stk_size,
                         OS_ERR     *p_err)
   {
       CPU_INT32U *p_stk;
       p_stk = (CPU_INT32U *)p_stk_base;  // 栈基地址（高地址）
       
       // 初始化栈帧（从高地址向低地址填充）
       *--p_stk = (CPU_INT32U)0x01000000;  // xPSR（必须设置bit24为1，Thumb模式）
       *--p_stk = (CPU_INT32U)task;        // PC（任务入口函数地址）
       *--p_stk = (CPU_INT32U)0xFFFFFFFE;  // LR（返回地址，临时填充）
       *--p_stk = (CPU_INT32U)0x00000003;  // R12
       *--p_stk = (CPU_INT32U)0x00000002;  // R3
       *--p_stk = (CPU_INT32U)0x00000001;  // R2
       *--p_stk = (CPU_INT32U)0x00000000;  // R1
       *--p_stk = (CPU_INT32U)p_arg;       // R0（任务参数）
       
       // 初始化R4-R11（用户寄存器，需手动入栈）
       *--p_stk = 0x0000000C;  // R11
       *--p_stk = 0x0000000B;  // R10
       *--p_stk = 0x0000000A;  // R9
       *--p_stk = 0x00000009;  // R8
       *--p_stk = 0x00000007;  // R7
       *--p_stk = 0x00000006;  // R6
       *--p_stk = 0x00000005;  // R5
       *--p_stk = 0x00000004;  // R4
       
       *p_err = OS_ERR_NONE;
       return (OS_STK *)p_stk;  // 返回新的栈顶指针
   }
   ```

2. **系统滴答中断处理（`OS_CPU_SysTickHandler`）**：
   系统滴答定时器（SysTick）是uC/OS的时基，每1ms触发一次，需调用内核时基函数：
   ```c
   void OS_CPU_SysTickHandler(void)
   {
       OSIntEnter();       // 进入中断，禁止任务调度
       OSTimeTick();       // 更新系统时间，检查任务延时是否到期
       OSIntExit();        // 退出中断，若有更高优先级任务就绪则切换
   }
   ```

3. **中断使能/禁止函数**：
   ```c
   void  OS_CPU_IntDis(void)
   {
       __disable_irq();  // 关闭全局中断（Cortex-M3指令）
   }
   
   void  OS_CPU_IntEn(void)
   {
       __enable_irq();   // 开启全局中断
   }
   ```

#### 3.4 修改`os_cpu_a.asm`（汇编文件，任务切换核心）
Cortex-M3通过PendSV中断实现任务切换（PendSV优先级最低，确保不抢占其他中断），关键汇编代码：
```asm
        AREA    OS_CPU_PendSV_Handler, CODE, READONLY
        THUMB
        REQUIRE8
        PRESERVE8

OS_CPU_PendSVHandler
        ; 1. 保存当前任务上下文（R4-R11和PSP）
        CPSID   I                   ; 关闭中断，确保上下文保存完整
        MRS     R0, PSP             ; 读取进程栈指针（PSP，任务使用的栈）
        STMDB   R0!, {R4-R11}       ; 将R4-R11入栈（递减存储）
        LDR     R1, =OSTCBCurPtr    ; 获取当前任务TCB指针（OSTCBCurPtr是全局变量）
        LDR     R1, [R1]
        STR     R0, [R1]            ; 将新的栈顶指针保存到当前任务TCB
        
        ; 2. 切换到最高优先级就绪任务
        LDR     R0, =OSTCBHighRdyPtr; 获取最高优先级任务TCB指针
        LDR     R0, [R0]
        LDR     R1, =OSTCBCurPtr
        STR     R0, [R1]            ; 更新当前任务TCB为最高优先级任务
        
        ; 3. 恢复新任务上下文
        LDR     R0, [R0]            ; 从新任务TCB读取栈顶指针
        LDMIA   R0!, {R4-R11}       ; 恢复R4-R11（递增读取）
        MSR     PSP, R0             ; 更新PSP为新任务的栈顶指针
        CPSIE   I                   ; 开启中断
        BX      LR                  ; 退出中断，执行新任务
        END
```


### 阶段4：系统初始化与任务创建
#### 4.1 板级支持包`bsp.c`实现
```c
#include "bsp.h"
#include "stm32f1xx_hal.h"

void BSP_Init(void)
{
    // 配置SysTick定时器（1ms中断，作为uC/OS时基）
    SysTick_Config(SystemCoreClock / OS_CFG_TICK_RATE_HZ);  // 72MHz / 1000 = 72000计数
    
    // 配置PendSV中断优先级为最低（0xFF）
    NVIC_SetPriority(PendSV_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(), 0xFF, 0));
}
```

#### 4.2 任务实现（`tasks.c`）
1. **LED1任务（1秒周期）**：
   ```c
   #include "tasks.h"
   #include "os.h"
   #include "stm32f1xx_hal.h"

   void LED1_Task(void *p_arg)
   {
       OS_ERR err;
       (void)p_arg;  // 未使用参数
       
       while(1)
       {
           HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);  // 翻转LED1
           // 延时1秒（时:0, 分:0, 秒:1, 毫秒:0）
           OSTimeDlyHMSM(0, 0, 1, 0, OS_OPT_TIME_HMSM_STRICT, &err);
       }
   }
   ```

2. **LED2任务（3秒周期）**：
   ```c
   void LED2_Task(void *p_arg)
   {
       OS_ERR err;
       (void)p_arg;
       
       while(1)
       {
           HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin);  // 翻转LED2
           OSTimeDlyHMSM(0, 0, 3, 0, OS_OPT_TIME_HMSM_STRICT, &err);  // 延时3秒
       }
   }
   ```

3. **串口任务（2秒周期）**：
   ```c
   extern UART_HandleTypeDef huart1;  // CubeMX生成的USART1句柄

   void UART_Task(void *p_arg)
   {
       OS_ERR err;
       uint8_t tx_buf[] = "hello uc/OS! 欢迎来到RTOS多任务环境！\r\n";
       (void)p_arg;
       
       while(1)
       {
           HAL_UART_Transmit(&huart1, tx_buf, sizeof(tx_buf)-1, 100);  // 串口发送
           OSTimeDlyHMSM(0, 0, 2, 0, OS_OPT_TIME_HMSM_STRICT, &err);  // 延时2秒
       }
   }
   ```

#### 4.3 主函数（`main.c`）
```c
#include "main.h"
#include "os.h"
#include "bsp.h"
#include "tasks.h"

// 任务栈和控制块定义
OS_STK LED1_TaskStk[APP_CFG_LED1_TASK_STK_SIZE];
OS_STK LED2_TaskStk[APP_CFG_LED2_TASK_STK_SIZE];
OS_STK UART_TaskStk[APP_CFG_UART_TASK_STK_SIZE];

OS_TCB LED1_TaskTCB;
OS_TCB LED2_TaskTCB;
OS_TCB UART_TaskTCB;

int main(void)
{
    OS_ERR err;
    
    // 1. 硬件初始化
    HAL_Init();
    SystemClock_Config();  // 系统时钟初始化（72MHz）
    MX_GPIO_Init();        // GPIO初始化（LED）
    MX_USART1_UART_Init(); // 串口初始化
    BSP_Init();            // uC/OS硬件初始化（SysTick、PendSV）
    
    // 2. 初始化uC/OS-III内核
    OSInit(&err);
    if (err != OS_ERR_NONE)
    {
        // 初始化失败处理（可点亮错误LED）
        while(1);
    }
    
    // 3. 创建任务1（LED1，优先级5）
    OSTaskCreate((OS_TCB     *)&LED1_TaskTCB,
                 (CPU_CHAR   *)"LED1 Task",
                 (OS_TASK_PTR )LED1_Task,
                 (void       *)0,
                 (OS_PRIO     )APP_CFG_LED1_TASK_PRIO,
                 (OS_STK     *)&LED1_TaskStk[0],
                 (OS_STK_SIZE )LED1_TaskStk[APP_CFG_LED1_TASK_STK_SIZE / 10],  // 栈限制（1/10处）
                 (OS_STK_SIZE )APP_CFG_LED1_TASK_STK_SIZE,
                 (OS_MSG_QTY  )0,  // 不使用消息队列
                 (OS_TICK     )0,  // 立即启动
                 (void       *)0,  // 无额外参数
                 (OS_OPT      )OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR,  // 栈检查+清零
                 (OS_ERR     *)&err);
    
    // 创建任务2（LED2，优先级6）和任务3（UART，优先级7），代码类似上述
    
    // 4. 启动uC/OS-III，开始任务调度
    OSStart(&err);
    
    // 永远不会执行到这里
    while (1)
    {
    }
}
```


### 阶段5：工程编译配置
1. **添加宏定义**：
   右键工程→“Options for Target”→“C/C++”→“Define”，添加：
   ```
   USE_HAL_DRIVER,STM32F103xB,OS_CFG_APP_HOOKS_EN=1,CPU_CFG_CRITICAL_METHOD=3
   ```
   （`CPU_CFG_CRITICAL_METHOD=3`指定Cortex-M3的临界区实现方式）

2. **添加包含路径**：
   在“Include Paths”中添加所有源码目录：
   ```
   ..\uCOS\uC-CPU
   ..\uCOS\uC-CPU\ARM-Cortex-M3
   ..\uCOS\uC-LIB
   ..\uCOS\uC-OS-III
   ..\uCOS\uC-OS-III\Source
   ..\uCOS\BSP
   ```

3. **配置栈大小**：
   进入“Linker”→“IROM1”设置为`0x08000000, 0x00080000`（512KB Flash），“IRAM1”设置为`0x20000000, 0x00005000`（20KB RAM）。
   在“Scatter File”中确保栈堆大小足够：`Stack_Size = 0x800`，`Heap_Size = 0x800`。


## 四、实验结果与验证
1. **编译下载**：
   - 点击“Build”，确保0 Errors、0 Warnings。
   - 通过ST-Link下载程序到STM32F103。

2. **现象观察**：
   - **LED1**：每1秒闪烁一次（亮1秒→灭1秒）。
   - **LED2**：每3秒闪烁一次（亮3秒→灭3秒）。
   - **串口助手**：设置波特率115200，每2秒收到一行字符串：`hello world`。

3. **结果分析**：
   - 多任务并行运行，证明uC/OS-III调度正常。
   - 周期准确，说明时基配置（SysTick+`OS_CFG_TICK_RATE_HZ`）正确。
   - 无任务阻塞，验证任务栈大小和优先级设置合理。


## 五、移植常见问题与解决方案
| 问题现象                | 可能原因                                  | 解决方案                                  |
|-------------------------|-------------------------------------------|-------------------------------------------|
| 编译报错“os_cpu_a.asm: 未定义符号” | 汇编文件未添加到工程，或路径错误          | 确认`os_cpu_a.asm`已添加到`uC-CPU`分组    |
| 任务无法切换，LED不闪烁 | PendSV中断优先级未设为最低                | 在`BSP_Init()`中设置`NVIC_SetPriority(PendSV_IRQn, 0xFF)` |
| 延时不准确              | SysTick配置与`OS_CFG_TICK_RATE_HZ`不匹配  | 确保`SysTick_Config(SystemCoreClock / 1000)` |
| 串口乱码                | 波特率错误或PA9/PA10接反                  | 确认波特率115200，交叉连接（TX→RX，RX→TX） |
| 程序崩溃（HardFault）   | 任务栈大小不足                            | 增大栈大小（如从128改为256）              |


## 六、实验总结
本实验通过7个关键步骤完成了uC/OS-III在STM32F103上的移植：基础工程创建→源码导入→配置文件修改→核心移植文件（`os_cpu_c.c`/`os_cpu_a.asm`）实现→任务编写→工程配置→下载验证。重点在于理解Cortex-M3的栈结构、PendSV中断任务切换机制，以及uC/OS-III与硬件的接口原理。实验结果验证了多任务调度的实时性，为后续复杂嵌入式系统开发奠定基础。
