#ifndef __AHT20_H
#define __AHT20_H

#include "stm32f1xx_hal.h"

// AHT20 I2C地址（7位地址：0x38）
#define AHT20_ADDR         0x38 << 1  // 8位地址（写：0x70，读：0x71，通过HAL库自动处理读写位）

// AHT20命令
#define AHT20_CMD_INIT     0xE1  // 初始化命令
#define AHT20_CMD_MEASURE  0xAC  // 测量命令

// 函数声明
uint8_t AHT20_Init(I2C_HandleTypeDef *hi2c);  // 初始化AHT20
uint8_t AHT20_ReadData(I2C_HandleTypeDef *hi2c, float *temp, float *humi);  // 读取温湿度

#endif
