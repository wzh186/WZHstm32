﻿# STM32F103 中断控制 LED 流水灯实验报告（HAL 库实现）

## 一、实验目的
1. 掌握 STM32 HAL 库的开发流程，包括 STM32CubeMX 配置与 Keil 代码编写。
2. 理解 STM32 外部中断原理，实现通过按键（开关）中断控制 LED 流水灯的启停。
3. 熟悉 GPIO 输出与外部中断的硬件配置及软件逻辑联动。


## 二、实验原理
### 1. 外部中断原理
STM32 的 GPIO 引脚可配置为外部中断模式，当引脚电平发生指定跳变（上升沿、下降沿或双边沿）时，会触发中断请求。中断请求通过 **嵌套向量中断控制器（NVIC）** 进行优先级管理后，调用对应的中断服务函数（ISR）。

本实验中，PB9 引脚配置为**双边沿触发中断**（上升沿/下降沿均触发），用于检测开关的电平变化；PA0、PA1、PA2 配置为 GPIO 输出，用于控制 LED 流水灯。

### 2. HAL 库中断处理机制
HAL 库通过**回调函数**简化中断开发流程。当外部中断触发时，硬件自动调用 HAL 库的底层中断处理函数，最终触发用户重写的 `HAL_GPIO_EXTI_Callback` 回调函数，在该函数中可实现自定义的中断逻辑（如修改全局标志位）。


## 三、实验环境
- 硬件：STM32F103C8T6 核心板、ST-Link 调试器、LED 灯（3 只）、限流电阻（220Ω）、杜邦线、面包板。
- 软件：STM32CubeMX（版本 6.9.0+）、Keil MDK（版本 5.37+）、HAL 库（STM32F1xx HAL Driver）。


## 四、实验步骤

### 1. STM32CubeMX 配置
#### （1）新建工程并选择芯片
- 打开 STM32CubeMX，点击「File → New Project」，搜索并选择「STM32F103C8T6」，点击「Start Project」。

#### （2）配置 GPIO 引脚
- **LED 引脚（PA0、PA1、PA2）**：
  点击引脚图中 PA0、PA1、PA2，选择「GPIO_Output」；
  进入「Configuration → GPIO」，设置模式为「Output Push Pull」，速度为「Low」，上下拉为「No pull-up and no pull-down」。
  ![在这里插入图片描述](https://i-blog.csdnimg.cn/direct/a2e68a14afca42da83a0db90b0da7053.png#pic_center)


- **中断引脚（PB9）**：
  点击引脚图中 PB9，选择「GPIO_EXTI9」；
  进入「Configuration → GPIO」，设置模式为「External Interrupt Mode with Rising/Falling edge trigger」，上下拉为「Pull-up」，速度为「Low」。
![在这里插入图片描述](https://i-blog.csdnimg.cn/direct/85db5e6d5e2b45da9267969acb67d0f4.png#pic_center)

#### （3）配置 NVIC 中断
- 进入「Configuration → NVIC」，勾选「EXTI line9 interrupt」的「Enabled」，保持默认优先级（Preemption Priority=0，Sub Priority=0）。
![在这里插入图片描述](https://i-blog.csdnimg.cn/direct/57235e5f6e7b4657b25d1238129c1515.png#pic_center)

#### （4）配置系统时钟
- 进入「Configuration → RCC」，选择「HSE → Crystal/Ceramic Resonator」（若使用外部晶振）；
- 进入「Configuration → Clock Configuration」，配置 PLL 使系统时钟为 72MHz（HSE 8MHz → PLL 倍频 9 倍 → 72MHz），APB1 分频为 2（36MHz）。结果PCLK1为36MHz就好
![在这里插入图片描述](https://i-blog.csdnimg.cn/direct/9d13d2659e654b6abb93df31b613979f.png#pic_center)

#### （5）生成工程代码
- 进入「Project Manager → Project」，设置工程名（如「HAL_Interrupt_LED」）、路径（英文无空格），选择「MDK-ARM」作为 IDE；
![在这里插入图片描述](https://i-blog.csdnimg.cn/direct/30c71680c4984e77ab4aa49a54de3fb2.png#pic_center)

- 进入「Project Manager → Code Generator」，勾选「Generate peripheral initialization as a pair of ‘.c/.h’ files per peripheral」
![在这里插入图片描述](https://i-blog.csdnimg.cn/direct/514b908385c24090bad107f3cf009682.png#pic_center)
配置完成后，点击「Generate Code」生成工程，然后进入keil5。

### 2. Keil 代码编写与调试
#### （1）添加全局标志位声明（`main.h`）
打开 `main.h`，在 `/* USER CODE BEGIN 0 */` 和 `/* USER CODE END 0 */` 之间添加：
```c
extern uint8_t led_run_flag;  // 声明全局标志位，控制流水灯启停
```
![在这里插入图片描述](https://i-blog.csdnimg.cn/direct/fd4693731aaa44fa8cd0cf565072bd56.png#pic_center)

#### （2）定义全局标志位与流水灯函数（`main.c`）
打开 `main.c`，在 `/* USER CODE BEGIN 0 */` 和 `/* USER CODE END 0 */` 之间添加：
```c
uint8_t led_run_flag = 0;  // 定义全局标志位，0=停止，1=运行

// 流水灯逻辑函数
void LED_Flow(void) {
    // 点亮PA0，熄灭PA1、PA2
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, GPIO_PIN_SET);
    HAL_Delay(500);

    // 点亮PA1，熄灭PA0、PA2
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, GPIO_PIN_SET);
    HAL_Delay(500);

    // 点亮PA2，熄灭PA0、PA1
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, GPIO_PIN_RESET);
    HAL_Delay(500);
}
```

#### （3）重写中断回调函数（`main.c`）
在 `main.c` 的 `/* USER CODE BEGIN 4 */` 和 `/* USER CODE END 4 */` 之间添加：
```c
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
    if (GPIO_Pin == GPIO_PIN_9) {  // 确认是PB9触发的中断
        if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_9) == GPIO_PIN_SET) {
            led_run_flag = 1;  // 开关高电平，流水灯运行
        } else {
            led_run_flag = 0;  // 开关低电平，流水灯停止
            // 停止时熄灭所有LED
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, GPIO_PIN_SET);
        }
    }
}
```

#### （4）修改主循环（`main.c`）
在 `main` 函数的 `while(1)` 循环中添加：
```c
while (1) {
    if (led_run_flag == 1) {
        LED_Flow();
    }
    /* USER CODE END 3 */
}
```


### 3. 硬件连接
- LED1（红）：PA0 → 限流电阻 → GND；
- LED2（绿）：PA1 → 限流电阻 → GND；
- LED3（黄）：PA2 → 限流电阻 → GND；
- 开关：PB9 → 杜邦线（可选接 VCC 或 GND，模拟开关动作）；
- ST-Link：SWD 接口与核心板连接，用于程序下载与调试。


## 五、实验结果与分析
### 1. 功能验证
- 当杜邦线将 PB9 接 VCC（高电平）时，`led_run_flag` 置 1，PA0、PA1、PA2 按 500ms 间隔轮流闪烁，流水灯功能正常。
- 当杜邦线将 PB9 接 GND（低电平）时，`led_run_flag` 置 0，所有 LED 熄灭，流水灯停止。
- 反复切换杜邦线电平，中断响应灵敏，流水灯启停逻辑无延迟。


### 2. 中断机制分析
HAL 库的 `HAL_GPIO_EXTI_Callback` 是中断处理的核心回调函数，通过「声明-定义」全局变量 `led_run_flag`，实现了中断逻辑与主循环的解耦。这种设计保证了中断的实时性（仅处理电平检测和标志位修改），同时让主循环专注于流水灯的业务逻辑，符合嵌入式开发的分层设计思想。


[video(video-dXRlpl4U-1762579803238)(type-csdn)(url-https://live.csdn.net/v/embed/499791)(image-https://i-blog.csdnimg.cn/direct/ed63b9d462524ab78d84d5078a40ba49.png)(title-11)]

## 六、总结
本实验通过 STM32CubeMX 快速配置硬件参数，结合 HAL 库的回调函数机制，实现了「开关中断控制 LED 流水灯启停」的功能。实验过程中需注意**全局变量的声明/定义规范**（避免重复定义错误），以及中断回调函数的逻辑完整性。

通过本次实验，深入理解了 STM32 外部中断的工作流程、HAL 库的封装逻辑，为后续复杂中断场景（如多按键中断、定时器中断）的开发奠定了基础。
